You can delete all the data that is filled using the field app. Also if you select to delete metadata, it'll delete all the forms and concept that you had created using web application.

**Please note that this action is irreversible so choose the options very carefully**
