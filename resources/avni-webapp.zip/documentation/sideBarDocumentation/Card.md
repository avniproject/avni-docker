Card contains the actual query that gets executed. Right now query should return a list of individual object.
