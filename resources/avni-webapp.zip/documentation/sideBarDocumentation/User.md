Logins for Avni. Users will get their first login details on email and SMS.

Ensure that you have created catchments for your users before creating them. Users can be created either through the [Users screen](/#/admin/user) or through the [upload screen](/#/admin/upload).

Users can be created or disabled. Disabled users cannot login. In case of password issues, the field application has the capability to reset passwords.

[Learn more about Users](https://avni.readme.io/docs/access-control)
