`Dashboard` created here will be shown in the field app.
You can add multiple `Sections` to a dashboard.
`Sections` will be shown in the same order as added here from the app-designer.
`Sections` can have multiple `Cards`, either in `Tile` or `List` format.
Within a `Section`, `Cards` will be shown in the same order as added here.

Collapse all the `Sections` for changing their order.
