Filters on the Search tab of the field app can be enhanced by adding filters here.

[Look up more details](https://avni.readme.io/docs/my-dashboard-and-search-filters)
