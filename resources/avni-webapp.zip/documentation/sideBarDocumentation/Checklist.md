Checklists are typically used to upload time-tables of things to do such as vaccination.

[Learn about uploading a checklist](https://avni.readme.io/docs/upload-checklist)
