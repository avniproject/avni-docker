Worklist updation rules help stitch together different workflows, such as registration, enrolment and completion of various forms.

[Learn more about writing rules](https://avni.readme.io/docs/rules-concept-guide)
