Custom web pages for the prints can be uploaded from here. All the required static files must be zipped and uploaded here. Below information is required while uploading the zip file.

`Label: Text that will appear on the subject dashboard`

`File Name: HTML file name that will be served when above label button is pressed`

Multiple `Label/FileName` can be added by clicking on `Add more extensions`
