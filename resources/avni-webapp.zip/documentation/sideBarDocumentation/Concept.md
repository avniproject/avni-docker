Concepts define the different pieces of information that you collect as part of your service delivery.

For example, if you collect the blood pressure of a subject in a form, then "Blood Pressure" should be defined as a concept. You would notice that every question in a form requires a concept

- [More information about concepts](https://avni.readme.io/docs/concepts)
- [Learn more about Avni's domain model](https://avni.readme.io/docs/avnis-domain-model-of-field-based-work)
