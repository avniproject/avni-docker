A program defines the service, or intervention that you provide to subjects.

A subject is enrolled into the program using the Enrolment Form. Routine information is collected through Encounters. A subject exits a program by filling in the Exit Form.

- [Learn more about Avni's domain model](https://avni.readme.io/docs/avnis-domain-model-of-field-based-work)
- [Learn more about writing rules](https://avni.readme.io/docs/rules-concept-guide)
