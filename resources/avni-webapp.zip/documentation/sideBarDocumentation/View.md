The views on this page are automatically generated or refreshed on click of `Create/Refresh View` button. There is one view corresponding to each form with every form field available as a column. These views help in writing the reports easily without having to understand the generic underlying Avni schema. Once generated, the views are available in Metabase or any other reporting tool you use.

The column names are based on form fields (concepts) which can be longer than permitted by the database, in such a case the names are shortened and you can see them at the top of view definition in comments. The format is - `Field name >> Shortened column name`.

Some types of change in form definition can cause these views to become obsolete. In such a case please regenerate these views and check your reports based on these views.
