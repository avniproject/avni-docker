This configuration is used to integrate with Msg91 to perform verification of phone numbers by sending an OTP.

[Learn more about Phone Number Verification](https://avni.readme.io/docs/phone-number-verification)
