You can create and publish news from here. Once news is published it starts showing up to the field users after sync.
