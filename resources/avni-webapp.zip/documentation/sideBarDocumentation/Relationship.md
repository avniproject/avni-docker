If you plan to store relationships of individuals between each other, define these relationships here.
