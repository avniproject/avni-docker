MyDashboard in Avni comes with some default filters. Additional filters can be added here.

[Look up more details](https://avni.readme.io/docs/my-dashboard-and-search-filters)
