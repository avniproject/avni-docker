After adding [languages](#/admin/language) you will be able to download/upload the translation file for all the different languages.

Learn more about [translation management](https://avni.readme.io/docs/translation-management).
