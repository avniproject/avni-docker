User Groups can be created to finely control user access to functions in the field and data entry apps.

By default, no configuration is required here as there is already an Everyone group that has all privileges.

[Learn more about Access Control and User Groups](https://avni.readme.io/docs/access-control)
