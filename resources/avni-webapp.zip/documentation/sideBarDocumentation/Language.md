Choose all the languages you need the app to be available in.

Users can choose the language of their choice through their settings. You should remember to provide translations for your forms in these languages through the [translations](/#/translations) section.

When creating users, you can also provide the default language for each user

[Learn more about translation management](https://avni.readme.io/docs/translation-management)
