Reports of different type can be generated from here.
