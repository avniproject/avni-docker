Configuration from an organisation can be exported and imported into another organisation. This helps migrating the implementation of a program from one organisation to another.
