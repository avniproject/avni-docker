self.__precacheManifest = [
  {
    "revision": "8edf836ff6d4cb987ad6ad734b4e02b4",
    "url": "/static/media/background.093629b1.jpg"
  },
  {
    "revision": "b42a730b01c55efe37722027d9cddd95",
    "url": "/static/media/avni-logo-black.3d9edae8.png"
  },
  {
    "revision": "46eadca893e77090e6548b1a5f157837",
    "url": "/static/media/avni-background.e9d465da.jpeg"
  },
  {
    "revision": "2b58aedf3309da0c97423a510c29794b",
    "url": "/static/media/Metabase_icon.2b58aedf.svg"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.42ac5946.js"
  },
  {
    "revision": "c93d1937a6998c540b72",
    "url": "/static/js/main.c93d1937.chunk.js"
  },
  {
    "revision": "1782a386deb29ba183d7",
    "url": "/static/js/2.1782a386.chunk.js"
  },
  {
    "revision": "c93d1937a6998c540b72",
    "url": "/static/css/main.a31d0ed9.chunk.css"
  },
  {
    "revision": "1782a386deb29ba183d7",
    "url": "/static/css/2.32bf8ecd.chunk.css"
  },
  {
    "revision": "391a33009a9a5a22368121d8895b2e61",
    "url": "/index.html"
  }
];