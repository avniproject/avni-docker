self.__precacheManifest = [
  {
    "revision": "3636111f80f91ef6b5bded1621c3b2fa",
    "url": "/static/media/login_image.3636111f.png"
  },
  {
    "revision": "8edf836ff6d4cb987ad6ad734b4e02b4",
    "url": "/static/media/background.8edf836f.jpg"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.42ac5946.js"
  },
  {
    "revision": "6dd4e5c1c216038954e5",
    "url": "/static/js/main.6dd4e5c1.chunk.js"
  },
  {
    "revision": "e058ffb6d027a07722ad",
    "url": "/static/js/2.e058ffb6.chunk.js"
  },
  {
    "revision": "6dd4e5c1c216038954e5",
    "url": "/static/css/main.de950fbc.chunk.css"
  },
  {
    "revision": "e058ffb6d027a07722ad",
    "url": "/static/css/2.5bdf83f6.chunk.css"
  },
  {
    "revision": "812b0163997fff921cb09ef0e5cccf3c",
    "url": "/index.html"
  }
];